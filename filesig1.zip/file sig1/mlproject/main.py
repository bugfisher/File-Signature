from wsgiref import simple_server
from flask import Flask, request, render_template
from werkzeug import secure_filename
import pickle
import json
import numpy as np

app = Flask(__name__)

def get_predict_profit(r_d_expenses, administration_expenses, marketing_expenses, state):
    """
    * method: get_predict_profit
    * description: method to predict the results
    * return: prediction result

    """
    with open('models/profit_prediction_model.pkl', 'rb') as f:
        model = pickle.load(f)

    with open("models/columns.json", "r") as f:
        data_columns = json.load(f)['data_columns']


    try:
        state_index = data_columns.index('state_'+str(state).lower())
    except:
        state_index = -1

    x = np.zeros(len(data_columns))
    x[0] = r_d_expenses
    x[1] = administration_expenses
    x[2] = marketing_expenses
    if state_index >= 0:
        x[state_index] = 1

    return round(model.predict([x])[0],2)

def get_file_sig(filename):
    with open('models/model.pkl', 'rb') as f:
        model = pickle.load(f)
    with open(filename, "r") as myfile:
            data = myfile.read().replace("\n", "")
    data = [data]
    return model.predict(data)
    



@app.route('/')
def index_page():
    """
    * method: index_page
    * description: method to call index html page
    * return: index.html

    """
    return render_template('index.html')

@app.route('/uploader', methods = ['GET', 'POST'])
def upload_file():
   if request.method == 'POST':
      f = request.files['file']
      f.save(secure_filename(f.filename))
      signature = get_file_sig(f.filename)
      print(signature)
      if signature[0] == 1:
          ans = "Javascript"
      else:
          ans = "CSV"  
      return render_template('index.html',show_hidden=True, prediction_text='File type is  {}'.format(ans))



if __name__ == "__main__":
    #app.run(debug=True)
    host = '0.0.0.0'
    port = 5000
    httpd = simple_server.make_server(host, port, app)
    httpd.serve_forever()